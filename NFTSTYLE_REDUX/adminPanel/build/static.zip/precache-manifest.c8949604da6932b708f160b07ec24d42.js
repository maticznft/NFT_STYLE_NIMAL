self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "b9cd60fbc1decf236fa6dab10b11c24f",
    "url": "/nimdaelytstfn/index.html"
  },
  {
    "revision": "e0116d6f1c86bccd2fae",
    "url": "/nimdaelytstfn/static/css/2.027076e1.chunk.css"
  },
  {
    "revision": "5405b002f8ed01adae91",
    "url": "/nimdaelytstfn/static/css/main.51610b50.chunk.css"
  },
  {
    "revision": "e0116d6f1c86bccd2fae",
    "url": "/nimdaelytstfn/static/js/2.da8baa6a.chunk.js"
  },
  {
    "revision": "1633f54e4f54fa93efb230901def260c",
    "url": "/nimdaelytstfn/static/js/2.da8baa6a.chunk.js.LICENSE.txt"
  },
  {
    "revision": "5405b002f8ed01adae91",
    "url": "/nimdaelytstfn/static/js/main.e3585be6.chunk.js"
  },
  {
    "revision": "f7bdf0cfc9ea0dd44285692948c2d84f",
    "url": "/nimdaelytstfn/static/js/main.e3585be6.chunk.js.LICENSE.txt"
  },
  {
    "revision": "2bc2617dff11d9549bb9",
    "url": "/nimdaelytstfn/static/js/runtime-main.eb838c02.js"
  },
  {
    "revision": "a84d4fbf2252a34f02fbad494e44985f",
    "url": "/nimdaelytstfn/static/media/auth_logo.a84d4fbf.png"
  },
  {
    "revision": "230c68c0a432ba95546bd76b718ade25",
    "url": "/nimdaelytstfn/static/media/coin_img.230c68c0.png"
  },
  {
    "revision": "8e9f0a3c5578a20733d5bad0e51c91fb",
    "url": "/nimdaelytstfn/static/media/sidebar-1.8e9f0a3c.jpg"
  },
  {
    "revision": "310509c95512893dc661bd3a6b0d2a5d",
    "url": "/nimdaelytstfn/static/media/sidebar-2.310509c9.jpg"
  },
  {
    "revision": "2503169017014036cf0dd0dd7c2a2b8a",
    "url": "/nimdaelytstfn/static/media/sidebar-3.25031690.jpg"
  },
  {
    "revision": "fc9cb0538eb5a4dfd6fbb1bf6dd6189b",
    "url": "/nimdaelytstfn/static/media/sidebar-4.fc9cb053.jpg"
  }
]);